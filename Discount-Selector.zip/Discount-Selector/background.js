/*
un-comment it to run script when clicked on the logo
chrome.browserAction.onClicked.addListener(function(activeTab) {
    executeScripts(null, [
        {file: "jquery-3.5.1.js"},
        {file: "content.js"}
    ])
});
*/