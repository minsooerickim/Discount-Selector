# Discount-Selector
 -brings all the items with a discount up to the top
 -gets rid of duplicate listings (usually ads)
